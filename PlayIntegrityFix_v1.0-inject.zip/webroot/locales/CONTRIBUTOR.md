# Play Integrity Fix WebUI Translation Contributor List

## Arabic

- [ZG089](https://github.com/ZG089)

---

## Indonesian

- [yourbestregard](https://github.com/yourbestregard)
- [Neebe3289](https://github.com/Neebe3289)

---

## Chinese (Simplified)

- [KawKabMod](https://github.com/KawKabMod)

---

## Chinese (Traditional)

- [mattchengg](https://github.com/mattchengg)

---

## English

- [KawKabMod](https://github.com/KawKabMod)

---

## Turkish

- [DogancanYr](https://github.com/DogancanYr)

